package ejercicio1;


public class ArithmeticException {
    //Indica cualquier excepción aritmetica
    
}
