package ejercicio1;

public class IllegalArgumentException {
    //Indica que algun metodo a recibido un argumento con un valor inapropiado o ilegal
}
