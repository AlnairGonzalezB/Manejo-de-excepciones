package ejercicio1;

public class NullPointerException {
    //Indica que se esta usando null en casos donde se usa un objeto
}
