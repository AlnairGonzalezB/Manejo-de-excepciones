package ejercicio1;

public class StackOverflowError {
    //Indica que existe un desbordamiento en la pila 
}
