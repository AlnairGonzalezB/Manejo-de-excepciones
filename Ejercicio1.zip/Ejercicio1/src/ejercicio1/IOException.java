package ejercicio1;

public class IOException {
    //Indica cuado tenemos un error I/O(Input/Output) esta excepción es de tipo verificada
}
