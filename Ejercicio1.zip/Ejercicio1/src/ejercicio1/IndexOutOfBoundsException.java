package ejercicio1;
import java.util.Scanner;

public class IndexOutOfBoundsException {
    //Indica que el indice de (arreglos, cadena, o vectores) esta fuera de rango
    int array[]={1,2,3};
    
    void metodo1()
    {
        System.out.println("Valor 3 del arreglo = "+array[3]);
    }
    void metodo2()
    {
        for(int i=0; i<1000; i++)
        {
            System.out.println("Valor del arreglo en "+1+" : "+array[i]);
        }
    }
    void metodo3()
    {
        Scanner scanner = new Scanner(System.in);
        int i;
        System.out.println("Dame el valor de i: ");
        i=scanner.nextInt();
        System.out.println("Arreglo en i: "+array[i]);
    }
}
