package ejercicio1;

public class Ejercicio1 {

    public static void main(String[] args) {
        IndexOutOfBoundsException exception1 = new IndexOutOfBoundsException();
        exception1.metodo3();
    }
}
