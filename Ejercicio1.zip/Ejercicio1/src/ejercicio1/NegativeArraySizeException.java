package ejercicio1;

public class NegativeArraySizeException {
    //Indica que se intento crear un arreglo de tamaño negativo
}
