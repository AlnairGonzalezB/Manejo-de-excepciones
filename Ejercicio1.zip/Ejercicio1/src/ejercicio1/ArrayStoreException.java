package ejercicio1;

public class ArrayStoreException {
    //Indica que se ha intentado guardar un tipo de objeto equivocado en un arreglo de objetos
}
