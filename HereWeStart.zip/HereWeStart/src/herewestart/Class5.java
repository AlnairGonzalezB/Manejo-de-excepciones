package herewestart;
import java.util.Vector;

public class Class5 {
    Vector vector = new Vector(5);
    Class1 object = new Class1();
    void imBad(){
            System.out.println("Vector en 50"+vector.get(50));
        object.mark();
    }
}
