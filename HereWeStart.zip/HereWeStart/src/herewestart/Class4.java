package herewestart;

public class Class4 {
    Class3 object = null;
    Class3 object2 = new Class3();
    void metod598(){
        object.art();
        object2.art();
    }
}
