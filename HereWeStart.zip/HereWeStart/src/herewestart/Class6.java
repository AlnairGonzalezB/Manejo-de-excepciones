package herewestart;

public class Class6 {
    Class2 object = new Class2();
    int[] intArray = new int[]{1,2,3};
    
    void metod1(){
        metod2();
    }
    void metod2(){
        metod3();
    }
    void metod3(){
        metod5();
    }
    void metod4(){
        int y=0;
            for(int i=0; i<50; i++)
        {
            System.out.println("Valor en i: "+intArray[i]);
            System.out.println("Division sobre cero: "+intArray[i]/y);
        }
        object.metod3();
    }
    void metod5(){
        metod6();
    }
    void metod6(){
        metod7(5);
    }
    void metod7(int i){
        if (i == 0) 
            return; 
        else { 
            metod7(i++); 
        } 
    }
}
