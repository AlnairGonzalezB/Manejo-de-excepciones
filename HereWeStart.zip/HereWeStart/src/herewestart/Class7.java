package herewestart;

public class Class7 {
    Class6 object = new Class6();
    Class5 object2 = new Class5();
    void imNotBad(){
        object.metod4();
        object2.imBad();
    }
}
