package herewestart;

public class Class2 {
    
    void metod1(){
        
    }
    void metod2(){
            int nothingHappens=1/0;
    }
    void metod3(){
        int[] intArray = new int[]{1,2,3};
        for(int i=0; i>6; i=+2){
            System.out.println("Por aqui vamos");
            System.out.println("  Por aqui hay algo mal  " +intArray[40]);
        }
        metod2();
    }
}
