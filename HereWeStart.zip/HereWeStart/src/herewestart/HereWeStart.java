package herewestart;

public class HereWeStart {

    public static void main(String[] args) {
        Class6 object = new Class6();
        Class7 object2 = new Class7();
        object.metod4();
        object2.imNotBad();
        System.out.println("!!!!!Llegaste !!!!!!!");
    }
    
}
