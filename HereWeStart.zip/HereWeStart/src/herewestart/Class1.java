package herewestart;

public class Class1 {
    Class4 object = new Class4();
    void mark(){
        System.out.println("Johnny’s my best friend");
        tommy();
    }
    void tommy(){
        System.out.println("I did not hit her");
        theRoom();
    }
    void theRoom(){
        System.out.println("Best movie");
        theAvengers();
    }
    void theAvengers(){
            Object x[] = new String[3];
            x[0] = new Integer(0);
        object.metod598();
    }
}
